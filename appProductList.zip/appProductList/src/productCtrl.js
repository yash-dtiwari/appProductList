app.controller('productDetailCtrl', [
    '$scope',
    '$http',
    'ngDialog',
    function($scope, $http, ngDialog) {


        $scope.init = function() {
            
            //let productJSON = 'https://www.westelm.com/services/catalog/v4/category/shop/new/all-new/index.json';
            let productJSON  = './json/product_JSON.json';
            $scope.objProduct = [];

                var headerObj = {
                 // 'Authorization': 'Basic ' + btoa(username + ":" + password),
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json; charset=utf-8',
                "X-Requested-With": "XMLHttpRequest"
                  }

              $http({
                    method : "GET",
                    url : productJSON,
                    headers: headerObj
                }).then(function mySuccess(response) {
                    console.log("in success",response);
                    $scope.objProduct = response.data.groups;
                }, function myError(response) {
                    console.log("in error",response);
                });
        } 


    //calling on init of controller to get JSON data
    $scope.init();

    $scope.openDialog = function() {

        //calling dialog to show carousel
        ngDialog.open({
            templateUrl: 'carouselTemplate.html',
            closeByDocument: true,
            closeByEscape: true,
            scope: $scope,
            className: 'ngdialog-theme-default product-dialog'
       });

    }

     
}]);



